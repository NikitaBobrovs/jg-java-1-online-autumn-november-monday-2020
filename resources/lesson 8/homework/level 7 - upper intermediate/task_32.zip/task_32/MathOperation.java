package teacher.lesson_8_inheritance.homework.level_7_senior.task_32;

abstract class MathOperation {

	public abstract double calculate();

}
